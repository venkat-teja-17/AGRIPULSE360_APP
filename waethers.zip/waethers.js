// script.js
document.addEventListener("DOMContentLoaded", () => {
  const locationElement = document.getElementById("location");
  const weatherCondition = document.getElementById("weather-condition");
  const weatherIcon = document.getElementById("weather-icon");
  const currentTime = document.getElementById("current-time");
  const currentDate = document.getElementById("current-date");

  // Get current date and time
  const updateTime = () => {
    const now = new Date();
    const options = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
    currentTime.textContent = now.toLocaleTimeString();
    currentDate.textContent = now.toLocaleDateString(undefined, options);
  };
  setInterval(updateTime, 1000); // Update every second
  updateTime();

  // Fetch weather data
  const fetchWeather = (latitude, longitude) => {
    const apiKey = "86ccb73ed1ff53b66f941b3037bf5e0e";
    const url = `https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&units=metric&appid=${apiKey}`;

    fetch(url)
      .then((response) => response.json())
      .then((data) => {
        const { main, weather } = data;
        const condition = weather[0].description;
        const icon = weather[0].icon;

        weatherCondition.textContent = condition.charAt(0).toUpperCase() + condition.slice(1);
        weatherIcon.textContent = `🌡️ ${Math.round(main.temp)}°C`;
      })
      .catch((error) => {
        console.error("Error fetching weather data:", error);
        weatherCondition.textContent = "Unable to fetch weather data.";
      });
  };

  // Get user location
  const getUserLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          const geocoder = new google.maps.Geocoder();
          const latlng = { lat: latitude, lng: longitude };

          geocoder.geocode({ location: latlng }, (results, status) => {
            if (status === "OK" && results[0]) {
              locationElement.textContent = `📍 ${results[0].formatted_address}`;
            } else {
              locationElement.textContent = "📍 Unable to fetch location.";
            }
          });

          fetchWeather(latitude, longitude);
        },
        () => {
          locationElement.textContent = "📍 Location access denied.";
        }
      );
    } else {
      locationElement.textContent = "📍 Geolocation not supported by this browser.";
    }
  };

  getUserLocation();
});
